public class Main {
    public static void main(String[] args) {
        CalcV1 calcv1 = new CalcV1();
        while (calcv1.run) {
            calcv1.run();
        }
    }
}
