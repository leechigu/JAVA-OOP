
public interface State {

	
	public void inputNumber(int input);
	public void inputOperator(char Sign);
	public void inputQuitSign();
	public void inputFinishOperator(char finishSign);
}
